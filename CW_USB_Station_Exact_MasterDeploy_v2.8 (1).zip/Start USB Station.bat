@echo off
cd /d "%~dp0"
py -3 station.py
if errorlevel 1 python station.py
pause
