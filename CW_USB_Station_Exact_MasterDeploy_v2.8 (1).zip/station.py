import os
import pathlib
import shutil
import subprocess
import sys
import time
from datetime import datetime

BASE = pathlib.Path(__file__).resolve().parent
MASTER = BASE / "CoombsWorks-Pixel9a-GIF-MasterDeploy-v2.8"
SCRIPT = MASTER / "RUN-PIXEL9A-MASTER-DEPLOY-AUTO.cmd"
POLL_SECONDS = 2

def adb_executable():
    candidates = [
        MASTER / "platform-tools" / "adb.exe",
        pathlib.Path(os.environ.get("LOCALAPPDATA", "")) / "Android" / "Sdk" / "platform-tools" / "adb.exe",
    ]
    for env in ("ANDROID_SDK_ROOT", "ANDROID_HOME"):
        if os.environ.get(env):
            candidates.append(pathlib.Path(os.environ[env]) / "platform-tools" / "adb.exe")
    candidates.append(shutil.which("adb.exe") or "")
    return next((str(p) for p in candidates if p and pathlib.Path(p).is_file()), None)

def devices(adb):
    p = subprocess.run([adb, "devices"], capture_output=True, text=True, timeout=15)
    if p.returncode:
        return []
    return [parts[0] for line in p.stdout.splitlines()[1:]
            if len(parts := line.split()) >= 2 and parts[1] == "device"]

def pixel9a(adb, serial):
    try:
        p = subprocess.run([adb, "-s", serial, "shell", "getprop", "ro.product.model"],
                           capture_output=True, text=True, timeout=15)
        return p.returncode == 0 and p.stdout.strip().lower() == "pixel 9a"
    except Exception:
        return False

def main():
    if os.name != "nt":
        sys.exit("This station requires Windows.")
    print("CW USB Station — original MasterDeploy v2.8")
    print("IMPORTANT: This runs the original script's user-0 AND user-10 changes,")
    print("installs CWReceiver, and attempts SwimUpstream Wi-Fi connection.")
    print("Only connect authorized, provisioned Pixel 9a devices.")
    print("Disconnect/reconnect to run again. Ctrl+C to stop.\n")
    seen = set()
    while True:
        adb = adb_executable()
        if not adb:
            print("ADB missing. Install Android platform-tools or place platform-tools beside master script.")
            time.sleep(10)
            continue
        try:
            present = set(devices(adb))
            seen.intersection_update(present)
            for serial in sorted(present - seen):
                seen.add(serial)
                if not pixel9a(adb, serial):
                    print(f"[SKIP] {serial}: not identified as Pixel 9a")
                    continue
                env = os.environ.copy()
                env["CW_SERIAL"] = serial
                log_dir = BASE / "logs"
                log_dir.mkdir(exist_ok=True)
                stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                log = log_dir / f"{stamp}-{serial.replace(':','_')}.log"
                print(f"[START] {serial}: {log}")
                with log.open("w", encoding="utf-8", errors="replace") as out:
                    proc = subprocess.Popen(["cmd.exe", "/d", "/c", str(SCRIPT)],
                                            cwd=str(MASTER), env=env,
                                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                            text=True, errors="replace")
                    for line in proc.stdout:
                        print(line, end="")
                        out.write(line)
                        out.flush()
                    code = proc.wait()
                print(f"[DONE] {serial}: exit code {code}. Review verification warnings in {log}.")
            time.sleep(POLL_SECONDS)
        except KeyboardInterrupt:
            print("\nStopped.")
            break
        except Exception as e:
            print(f"[ERROR] {type(e).__name__}: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
