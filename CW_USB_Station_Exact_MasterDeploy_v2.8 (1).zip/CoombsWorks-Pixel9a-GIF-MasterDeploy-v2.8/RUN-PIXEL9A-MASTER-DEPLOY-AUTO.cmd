@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title CoombsWorks Pixel 9a GIF Master Deploy v2.8
color 0A
echo ============================================================
echo  CoombsWorks Pixel 9a GIF MASTER DEPLOY v2.8
echo  Pixel 9a baseline + Shopper Receiver v0.1.10 TEST BUILD
echo ============================================================
echo Walmart work profile user 10 must already be provisioned.
echo No automatic reboot. Safe to rerun on additional Pixel 9a devices.
echo.

set "ADB="
if exist "%~dp0platform-tools\adb.exe" set "ADB=%~dp0platform-tools\adb.exe"
if not defined ADB if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not defined ADB if defined ANDROID_SDK_ROOT if exist "%ANDROID_SDK_ROOT%\platform-tools\adb.exe" set "ADB=%ANDROID_SDK_ROOT%\platform-tools\adb.exe"
if not defined ADB if defined ANDROID_HOME if exist "%ANDROID_HOME%\platform-tools\adb.exe" set "ADB=%ANDROID_HOME%\platform-tools\adb.exe"
if not defined ADB for /f "delims=" %%A in ('where adb.exe 2^>nul') do if not defined ADB set "ADB=%%A"

if not defined ADB (
 echo ADB not found. Downloading official Google Android Platform Tools...
 powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $u='https://dl.google.com/android/repository/platform-tools-latest-windows.zip'; $z=Join-Path $env:TEMP 'cw-platform-tools.zip'; Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $z; Expand-Archive -LiteralPath $z -DestinationPath '%~dp0' -Force; Remove-Item -LiteralPath $z -Force"
 if exist "%~dp0platform-tools\adb.exe" set "ADB=%~dp0platform-tools\adb.exe"
)

if not defined ADB goto :NOADB
if not exist "%~dp0payload\CWReceiver.apk" goto :NOAPK

echo Using ADB: "%ADB%" -s "%CW_SERIAL%"
echo Plug in and unlock the Pixel. If prompted, tap Allow USB debugging.
"%ADB%" -s "%CW_SERIAL%" start-server >nul 2>&1
"%ADB%" -s "%CW_SERIAL%" wait-for-device
"%ADB%" -s "%CW_SERIAL%" shell echo CW_MASTER_ADB_OK > "%TEMP%\cw_master_adb.txt" 2>nul
if errorlevel 1 goto :NODEVICE
findstr /X /C:"CW_MASTER_ADB_OK" "%TEMP%\cw_master_adb.txt" >nul
if errorlevel 1 goto :NODEVICE
del /q "%TEMP%\cw_master_adb.txt" >nul 2>&1

set "HAS10=0"
"%ADB%" -s "%CW_SERIAL%" shell pm list users | findstr /c:"{10:" >nul && set "HAS10=1"
if "!HAS10!"=="0" (
 color 0E
 echo ERROR: Walmart work profile user 10 was not found.
 echo Provision the work profile first, then rerun.
 pause
 exit /b 1
)

for /f "delims=" %%S in ('"%ADB%" -s "%CW_SERIAL%" get-serialno') do set "SERIAL=%%S"
set "RESTORE=%~dp0RESTORE-!SERIAL!.cmd"
>"!RESTORE!" echo @echo off
>>"!RESTORE!" echo setlocal EnableExtensions
>>"!RESTORE!" echo set "ADB=%%LOCALAPPDATA%%\Android\Sdk\platform-tools\adb.exe"
>>"!RESTORE!" echo if not exist "%%ADB%%" set "ADB=adb.exe"
>>"!RESTORE!" echo "%%ADB%%" wait-for-device

set /a CHANGED=0
set /a FAILED=0
set /a MISSING=0
set /a VERIFYFAIL=0

echo [1/6] Enforcing required keep state...
call :ENABLE 0 com.android.chrome
call :ENABLE 0 com.google.android.GoogleCamera
call :ENABLE 10 com.airwatch.browser
call :ENABLE 10 com.airwatch.tunnel
call :ENABLE 10 com.walmart.sso.app

echo [2/6] Applying proven package state...
call :DISABLE 0 com.airwatch.contentlocker
call :DISABLE 10 com.airwatch.contentlocker
call :DISABLE 0 com.android.DeviceAsWebcam
call :DISABLE 10 com.android.DeviceAsWebcam
call :DISABLE 0 com.android.bips
call :DISABLE 10 com.android.bips
call :DISABLE 0 com.android.bookmarkprovider
call :DISABLE 10 com.android.bookmarkprovider
call :DISABLE 0 com.android.devicediagnostics
call :DISABLE 10 com.android.devicediagnostics
call :DISABLE 0 com.android.dynsystem
call :DISABLE 10 com.android.dynsystem
call :DISABLE 0 com.android.egg
call :DISABLE 10 com.android.egg
call :DISABLE 0 com.android.htmlviewer
call :DISABLE 10 com.android.htmlviewer
call :DISABLE 0 com.android.musicfx
call :DISABLE 10 com.android.musicfx
call :DISABLE 0 com.android.printspooler
call :DISABLE 10 com.android.printspooler
call :DISABLE 0 com.android.providers.partnerbookmarks
call :DISABLE 10 com.android.providers.partnerbookmarks
call :DISABLE 0 com.android.traceur
call :DISABLE 10 com.android.traceur
call :DISABLE 0 com.fitbit.FitbitMobile
call :DISABLE 10 com.fitbit.FitbitMobile
call :DISABLE 0 com.google.ambient.streaming
call :DISABLE 10 com.google.ambient.streaming
call :DISABLE 0 com.google.android.accessibility.soundamplifier
call :DISABLE 10 com.google.android.accessibility.soundamplifier
call :DISABLE 0 com.google.android.accessibility.switchaccess
call :DISABLE 10 com.google.android.accessibility.switchaccess
call :DISABLE 0 com.google.android.apps.accessibility.voiceaccess
call :DISABLE 10 com.google.android.apps.accessibility.voiceaccess
call :DISABLE 0 com.google.android.apps.adm
call :DISABLE 10 com.google.android.apps.adm
call :DISABLE 0 com.google.android.apps.ai.icons
call :DISABLE 10 com.google.android.apps.ai.icons
call :DISABLE 0 com.google.android.apps.bard
call :DISABLE 10 com.google.android.apps.bard
call :DISABLE 0 com.google.android.apps.chromecast.app
call :DISABLE 10 com.google.android.apps.chromecast.app
call :DISABLE 0 com.google.android.apps.docs
call :DISABLE 10 com.google.android.apps.docs
call :DISABLE 0 com.google.android.apps.docs.editors.docs
call :DISABLE 10 com.google.android.apps.docs.editors.docs
call :DISABLE 0 com.google.android.apps.dreamliner
call :DISABLE 10 com.google.android.apps.dreamliner
call :DISABLE 0 com.google.android.apps.internal.betterbug
call :DISABLE 10 com.google.android.apps.internal.betterbug
call :DISABLE 0 com.google.android.apps.magazines
call :DISABLE 10 com.google.android.apps.magazines
call :DISABLE 0 com.google.android.apps.magicportrait
call :DISABLE 10 com.google.android.apps.magicportrait
call :DISABLE 0 com.google.android.apps.maps
call :DISABLE 10 com.google.android.apps.maps
call :DISABLE 0 com.google.android.apps.messaging
call :DISABLE 10 com.google.android.apps.messaging
call :DISABLE 0 com.google.android.apps.nbu.files
call :DISABLE 10 com.google.android.apps.nbu.files
call :DISABLE 0 com.google.android.apps.photos
call :DISABLE 10 com.google.android.apps.photos
call :DISABLE 0 com.google.android.apps.photosgo
call :DISABLE 10 com.google.android.apps.photosgo
call :DISABLE 0 com.google.android.apps.pixel.creativeassistant
call :DISABLE 10 com.google.android.apps.pixel.creativeassistant
call :DISABLE 0 com.google.android.apps.pixel.familyspace
call :DISABLE 10 com.google.android.apps.pixel.familyspace
call :DISABLE 0 com.google.android.apps.pixel.nowplaying
call :DISABLE 10 com.google.android.apps.pixel.nowplaying
call :DISABLE 0 com.google.android.apps.pixel.relationships
call :DISABLE 10 com.google.android.apps.pixel.relationships
call :DISABLE 0 com.google.android.apps.pixel.support
call :DISABLE 10 com.google.android.apps.pixel.support
call :DISABLE 0 com.google.android.apps.recorder
call :DISABLE 10 com.google.android.apps.recorder
call :DISABLE 0 com.google.android.apps.retaildemo.preload
call :DISABLE 10 com.google.android.apps.retaildemo.preload
call :DISABLE 0 com.google.android.apps.subscriptions.red
call :DISABLE 10 com.google.android.apps.subscriptions.red
call :DISABLE 0 com.google.android.apps.tachyon
call :DISABLE 10 com.google.android.apps.tachyon
call :DISABLE 0 com.google.android.apps.tips
call :DISABLE 10 com.google.android.apps.tips
call :DISABLE 0 com.google.android.apps.translate
call :DISABLE 10 com.google.android.apps.translate
call :DISABLE 0 com.google.android.apps.walletnfcrel
call :DISABLE 10 com.google.android.apps.walletnfcrel
call :DISABLE 0 com.google.android.apps.wear.companion
call :DISABLE 10 com.google.android.apps.wear.companion
call :DISABLE 0 com.google.android.apps.wearables.maestro.companion
call :DISABLE 10 com.google.android.apps.wearables.maestro.companion
call :DISABLE 0 com.google.android.apps.weather
call :DISABLE 10 com.google.android.apps.weather
call :DISABLE 0 com.google.android.apps.wellbeing
call :DISABLE 10 com.google.android.apps.wellbeing
call :DISABLE 0 com.google.android.apps.youtube.music
call :DISABLE 10 com.google.android.apps.youtube.music
call :DISABLE 0 com.google.android.calculator
call :DISABLE 10 com.google.android.calculator
call :DISABLE 0 com.google.android.calendar
call :DISABLE 10 com.google.android.calendar
call :DISABLE 0 com.google.android.contacts
call :DISABLE 10 com.google.android.contacts
call :DISABLE 0 com.google.android.deskclock
call :DISABLE 10 com.google.android.deskclock
call :DISABLE 0 com.google.android.feedback
call :DISABLE 10 com.google.android.feedback
call :DISABLE 0 com.google.android.gm
call :DISABLE 10 com.google.android.gm
call :DISABLE 0 com.google.android.gms.location.history
call :DISABLE 10 com.google.android.gms.location.history
call :DISABLE 0 com.google.android.googlequicksearchbox
call :DISABLE 10 com.google.android.googlequicksearchbox
call :DISABLE 0 com.google.android.googlequicksearchbox.nga_resources
call :DISABLE 10 com.google.android.googlequicksearchbox.nga_resources
call :DISABLE 0 com.google.android.health.connect.backuprestore
call :DISABLE 10 com.google.android.health.connect.backuprestore
call :DISABLE 0 com.google.android.healthconnect.controller
call :DISABLE 10 com.google.android.healthconnect.controller
call :DISABLE 0 com.google.android.keep
call :DISABLE 10 com.google.android.keep
call :DISABLE 0 com.google.android.markup
call :DISABLE 10 com.google.android.markup
call :DISABLE 0 com.google.android.marvin.talkback
call :DISABLE 10 com.google.android.marvin.talkback
call :DISABLE 0 com.google.android.printservice.recommendation
call :DISABLE 10 com.google.android.printservice.recommendation
call :DISABLE 0 com.google.android.projection.gearhead
call :DISABLE 10 com.google.android.projection.gearhead
call :DISABLE 0 com.google.android.uvexposurereporter
call :DISABLE 10 com.google.android.uvexposurereporter
call :DISABLE 0 com.google.android.videos
call :DISABLE 10 com.google.android.videos
call :DISABLE 0 com.google.android.youtube
call :DISABLE 10 com.google.android.youtube
call :DISABLE 0 com.google.audio.hearing.visualization.accessibility.scribe
call :DISABLE 10 com.google.audio.hearing.visualization.accessibility.scribe
call :DISABLE 0 com.google.mainline.telemetry
call :DISABLE 10 com.google.mainline.telemetry
call :DISABLE 0 com.microsoft.office.outlook
call :DISABLE 10 com.microsoft.office.outlook
call :DISABLE 0 com.microsoft.windowsintune.companyportal
call :DISABLE 10 com.microsoft.windowsintune.companyportal
call :DISABLE 0 com.walmart.android
call :DISABLE 10 com.walmart.android
call :DISABLE 0 com.walmart.retailtech.storesystems.rct.disposition
call :DISABLE 10 com.walmart.retailtech.storesystems.rct.disposition
call :DISABLE 0 com.walmart.wmevents
call :DISABLE 10 com.walmart.wmevents
call :DISABLE 0 com.android.dreams.basic
call :DISABLE 10 com.android.dreams.basic
call :DISABLE 0 com.android.mtp
call :DISABLE 10 com.android.mtp
call :DISABLE 0 com.android.backupconfirm
call :DISABLE 10 com.android.backupconfirm
call :DISABLE 0 com.android.sharedstoragebackup
call :DISABLE 10 com.android.sharedstoragebackup
call :DISABLE 0 com.android.safetyregulatoryinfo
call :DISABLE 10 com.android.safetyregulatoryinfo
call :DISABLE 0 com.google.android.glasses.core
call :DISABLE 10 com.google.android.glasses.core
call :DISABLE 0 com.google.android.apps.safetyhub
call :DISABLE 10 com.google.android.apps.safetyhub
call :DISABLE 0 com.google.android.dreamlinerupdater
call :DISABLE 10 com.google.android.dreamlinerupdater
call :DISABLE 0 com.google.android.apps.carrier.log
call :DISABLE 10 com.google.android.apps.carrier.log
call :DISABLE 0 com.google.android.carrierlocation
call :DISABLE 10 com.google.android.carrierlocation
call :DISABLE 0 com.android.localtransport
call :DISABLE 10 com.android.localtransport
call :DISABLE 0 com.google.android.apps.restore
call :DISABLE 10 com.google.android.apps.restore
call :DISABLE 0 com.google.android.aicore
call :DISABLE 0 com.google.android.as
call :DISABLE 0 com.google.android.as.oss
call :DISABLE 0 com.google.android.federatedcompute
call :DISABLE 0 com.google.android.ondevicepersonalization.services
call :DISABLE 0 com.google.android.settings.intelligence
call :DISABLE 0 com.google.android.apps.scone
call :DISABLE 0 com.google.android.apps.pixel.dcservice
call :DISABLE 0 com.google.android.tts
call :DISABLE 0 com.google.android.dialer
call :DISABLE 0 com.google.android.crossdeviceaccessservice
call :DISABLE 10 com.google.android.aicore
call :DISABLE 10 com.google.android.as
call :DISABLE 10 com.google.android.as.oss
call :DISABLE 10 com.google.android.federatedcompute
call :DISABLE 10 com.google.android.ondevicepersonalization.services
call :DISABLE 10 com.google.android.settings.intelligence
call :DISABLE 10 com.google.android.apps.scone
call :DISABLE 10 com.google.android.apps.pixel.dcservice
call :DISABLE 10 com.google.android.tts
call :DISABLE 10 com.google.android.dialer
call :DISABLE 10 com.google.android.crossdeviceaccessservice
call :DISABLE 0 com.android.vending
call :DISABLE 0 com.google.android.soundpicker
call :DISABLE 10 com.google.android.soundpicker
call :DISABLE 0 com.google.android.flipendo
call :DISABLE 0 com.google.android.setupwizard
call :DISABLE 0 com.google.android.pixel.setupwizard
call :DISABLE 0 com.google.android.apps.setupwizard.searchselector
call :DISABLE 0 com.google.android.repairmode
call :DISABLE 0 com.android.providers.calendar
call :DISABLE 0 com.google.android.carriersetup
call :DISABLE 0 com.google.omadm.trigger
call :DISABLE 0 com.android.omadm.service
call :DISABLE 0 com.android.imsserviceentitlement
call :DISABLE 0 com.google.android.wfcactivation
call :DISABLE 10 com.google.omadm.trigger
call :DISABLE 10 com.android.imsserviceentitlement
call :DISABLE 10 com.google.android.wfcactivation
call :DISABLE 10 com.verizon.mips.services
call :DISABLE 10 com.verizon.services

echo [3/6] Disabling background usage for work GIF and MyWalmart...
"%ADB%" -s "%CW_SERIAL%" shell cmd appops set --user 10 com.walmart.gif2 RUN_ANY_IN_BACKGROUND ignore
if errorlevel 1 (echo [FAIL] GIF background restriction& set /a FAILED+=1) else echo [PASS] GIF background usage OFF
"%ADB%" -s "%CW_SERIAL%" shell cmd appops set --user 10 com.walmart.squiggly RUN_ANY_IN_BACKGROUND ignore
if errorlevel 1 (echo [FAIL] MyWalmart background restriction& set /a FAILED+=1) else echo [PASS] MyWalmart background usage OFF
"%ADB%" -s "%CW_SERIAL%" shell cmd appops set --user 10 com.airwatch.tunnel RUN_ANY_IN_BACKGROUND allow
if errorlevel 1 (echo [FAIL] Tunnel unrestricted background& set /a FAILED+=1) else echo [PASS] Tunnel background usage unrestricted
>>"!RESTORE!" echo "%%ADB%%" shell cmd appops set --user 10 com.walmart.gif2 RUN_ANY_IN_BACKGROUND allow
>>"!RESTORE!" echo "%%ADB%%" shell cmd appops set --user 10 com.walmart.squiggly RUN_ANY_IN_BACKGROUND allow

echo [4/6] Installing Shopper Receiver v0.1.10 test APK...
"%ADB%" -s "%CW_SERIAL%" install -r "%~dp0payload\CWReceiver.apk" > "%TEMP%\cw_receiver_install.txt" 2>&1
type "%TEMP%\cw_receiver_install.txt"
findstr /I /C:"Success" "%TEMP%\cw_receiver_install.txt" >nul
if errorlevel 1 (
 set /a FAILED+=1
 echo [FAIL] Receiver install - STOPPING to avoid false success.
 echo Existing app and its data have NOT been uninstalled.
 echo If INSTALL_FAILED_UPDATE_INCOMPATIBLE appears, signatures differ.
 echo Do not uninstall until any pending Receiver records are backed up.
 pause
 exit /b 1
) else echo [PASS] Receiver installed/updated
del /q "%TEMP%\cw_receiver_install.txt" >nul 2>&1

echo [4b/6] Allowing Receiver background execution and battery exemption...
"%ADB%" -s "%CW_SERIAL%" shell cmd appops set --user 0 com.coombsworks.shopperreceiver RUN_ANY_IN_BACKGROUND allow
if errorlevel 1 (echo [FAIL] Receiver RUN_ANY_IN_BACKGROUND& set /a FAILED+=1) else echo [PASS] Receiver RUN_ANY_IN_BACKGROUND
"%ADB%" -s "%CW_SERIAL%" shell cmd appops set --user 0 com.coombsworks.shopperreceiver RUN_IN_BACKGROUND allow
if errorlevel 1 (echo [FAIL] Receiver RUN_IN_BACKGROUND& set /a FAILED+=1) else echo [PASS] Receiver RUN_IN_BACKGROUND
"%ADB%" -s "%CW_SERIAL%" shell dumpsys deviceidle whitelist +com.coombsworks.shopperreceiver > "%TEMP%\cw_receiver_idle.txt" 2>&1
if errorlevel 1 (echo [WARNING] Device idle exemption denied by Android policy& set /a VERIFYFAIL+=1) else echo [PASS] Receiver device idle exemption requested
 del /q "%TEMP%\cw_receiver_idle.txt" >nul 2>&1

echo [5/6] Enabling Receiver accessibility service...
set "CW_SERVICE=com.coombsworks.shopperreceiver/.GifNilAccessibilityService"
set "CURRENT_ACC="
for /f "usebackq delims=" %%A in (`"%ADB%" -s "%CW_SERIAL%" shell settings get secure enabled_accessibility_services 2^>nul`) do set "CURRENT_ACC=%%A"
if /i "!CURRENT_ACC!"=="null" set "CURRENT_ACC="
echo !CURRENT_ACC! | findstr /I /C:"!CW_SERVICE!" >nul
if errorlevel 1 (
 if defined CURRENT_ACC (
   "%ADB%" -s "%CW_SERIAL%" shell settings put secure enabled_accessibility_services "!CURRENT_ACC!:!CW_SERVICE!"
 ) else (
   "%ADB%" -s "%CW_SERIAL%" shell settings put secure enabled_accessibility_services "!CW_SERVICE!"
 )
)
"%ADB%" -s "%CW_SERIAL%" shell settings put secure accessibility_enabled 1

echo [6/6] Verification...
"%ADB%" -s "%CW_SERIAL%" shell pm path com.coombsworks.shopperreceiver | findstr /I /C:"package:" >nul
if errorlevel 1 (echo [FAIL] Receiver package& set /a VERIFYFAIL+=1) else echo [PASS] Receiver package
set "ACC_NOW="
for /f "usebackq delims=" %%A in (`"%ADB%" -s "%CW_SERIAL%" shell settings get secure enabled_accessibility_services 2^>nul`) do set "ACC_NOW=%%A"
echo !ACC_NOW! | findstr /I /C:"!CW_SERVICE!" >nul
if errorlevel 1 (echo [WARNING] Receiver accessibility service not enabled& set /a VERIFYFAIL+=1) else echo [PASS] Receiver accessibility
call :VERIFY_APPOP 0 com.coombsworks.shopperreceiver RUN_ANY_IN_BACKGROUND allow "Receiver background usage unrestricted"
call :VERIFY_APPOP 0 com.coombsworks.shopperreceiver RUN_IN_BACKGROUND allow "Receiver legacy background operation"
"%ADB%" -s "%CW_SERIAL%" shell dumpsys deviceidle whitelist | findstr /I /C:"com.coombsworks.shopperreceiver" >nul
if errorlevel 1 (echo [WARNING] Receiver not on device idle whitelist& set /a VERIFYFAIL+=1) else echo [PASS] Receiver device idle whitelist
"%ADB%" -s "%CW_SERIAL%" shell dumpsys accessibility | findstr /I /C:"com.coombsworks.shopperreceiver" >nul
if errorlevel 1 (echo [WARNING] Receiver not visible in accessibility service dump& set /a VERIFYFAIL+=1) else echo [PASS] Receiver accessibility service registered
call :VERIFY_ENABLED 0 com.android.chrome "Personal Chrome"
call :VERIFY_ENABLED 0 com.google.android.GoogleCamera "Personal Camera"
call :VERIFY_DISABLED 0 com.android.vending "Personal Play Store"
call :VERIFY_ENABLED 10 com.android.vending "Work Play Store"
call :VERIFY_ENABLED 10 com.android.chrome "Work Chrome"
call :VERIFY_ENABLED 10 com.walmart.gif2 "GIF2"
call :VERIFY_ENABLED 10 com.airwatch.browser "Web"
call :VERIFY_ENABLED 10 com.airwatch.tunnel "AirWatch Tunnel"
call :VERIFY_ENABLED 10 com.walmart.sso.app "SSO Client"
call :VERIFY_APPOP 10 com.airwatch.tunnel RUN_ANY_IN_BACKGROUND allow "Tunnel background usage unrestricted"
call :VERIFY_DISABLED 10 com.walmart.android "Consumer Walmart"
call :VERIFY_APPOP 10 com.walmart.gif2 RUN_ANY_IN_BACKGROUND ignore "GIF background usage OFF"
call :VERIFY_APPOP 10 com.walmart.squiggly RUN_ANY_IN_BACKGROUND ignore "MyWalmart background usage OFF"
call :VERIFY_ENABLED 10 com.airwatch.androidagent "AirWatch Agent"
call :VERIFY_ENABLED 10 com.airwatch.tunnel "AirWatch Tunnel"
call :VERIFY_ENABLED 10 com.google.android.apps.work.clouddpc "Android Device Policy"

echo.
echo [7/7] Connecting to requested Wi-Fi SwimUpstream...
echo Note: ADB Wi-Fi configuration can be blocked by Android or work policy.
"%ADB%" -s "%CW_SERIAL%" shell svc wifi enable >nul 2>&1
"%ADB%" -s "%CW_SERIAL%" shell cmd wifi connect-network "SwimUpstream" wpa2 "onboarding" > "%TEMP%\cw_master_wifi.txt" 2>&1
set "WIFI_COMMAND_FAILED=0"
if errorlevel 1 set "WIFI_COMMAND_FAILED=1"
findstr /I /C:"Error" /C:"Exception" /C:"Unknown command" /C:"not allowed" /C:"failed" "%TEMP%\cw_master_wifi.txt" >nul && set "WIFI_COMMAND_FAILED=1"
if "!WIFI_COMMAND_FAILED!"=="1" (
 echo [WARNING] Wi-Fi auto-connect was rejected or unsupported.
 type "%TEMP%\cw_master_wifi.txt"
 echo Open Settings on the phone, select SwimUpstream and enter the supplied password.
 set /a VERIFYFAIL+=1
 "%ADB%" -s "%CW_SERIAL%" shell am start -a android.settings.WIFI_SETTINGS >nul 2>&1
) else (
 echo [INFO] Wi-Fi connection request sent; checking current network...
 timeout /t 5 /nobreak >nul
 "%ADB%" -s "%CW_SERIAL%" shell cmd wifi status > "%TEMP%\cw_master_wifi_status.txt" 2>&1
 findstr /I /C:"SwimUpstream" "%TEMP%\cw_master_wifi_status.txt" >nul
 if errorlevel 1 (
  echo [WARNING] Could not verify SwimUpstream as connected. Check Wi-Fi on the phone.
  set /a VERIFYFAIL+=1
 ) else (
  echo [PASS] Wi-Fi status mentions SwimUpstream. Confirm Internet access on phone.
 )
 del /q "%TEMP%\cw_master_wifi_status.txt" >nul 2>&1
)
del /q "%TEMP%\cw_master_wifi.txt" >nul 2>&1

echo.
echo ============================================================
echo Device: !SERIAL!
echo Changed this run: !CHANGED!  Missing optional: !MISSING!
echo Disable/install failures: !FAILED!  Verify warnings: !VERIFYFAIL!
if "!FAILED!"=="0" if "!VERIFYFAIL!"=="0" (echo RESULT: PASS) else (echo RESULT: WARNING)
echo Restore file for packages changed THIS run: !RESTORE!
echo ============================================================
echo Test GIF login, pick walk, staging camera, barcode scan, SwimUpstream Wi-Fi,
echo AirWatch Tunnel, MyWalmart, personal Chrome and personal Camera.
echo Then reboot manually and repeat the test.
rem AUTO-STATION: no interactive pause
exit /b 0

:DISABLE
set "U=%~1"
set "PKG=%~2"
"%ADB%" -s "%CW_SERIAL%" shell pm path --user !U! !PKG! >nul 2>&1
if errorlevel 1 (set /a MISSING+=1& exit /b 0)
"%ADB%" -s "%CW_SERIAL%" shell pm list packages -d --user !U! | findstr /X /C:"package:!PKG!" >nul
if not errorlevel 1 exit /b 0
"%ADB%" -s "%CW_SERIAL%" shell pm disable-user --user !U! !PKG! > "%TEMP%\cw_master_pm.txt" 2>&1
findstr /I /C:"disabled" "%TEMP%\cw_master_pm.txt" >nul
if errorlevel 1 (
 set /a FAILED+=1
 echo [FAIL] disable u!U! !PKG!
) else (
 set /a CHANGED+=1
 echo [OK] disabled u!U! !PKG!
 >>"!RESTORE!" echo "%%ADB%%" shell pm enable --user !U! !PKG!
)
del /q "%TEMP%\cw_master_pm.txt" >nul 2>&1
exit /b 0

:ENABLE
set "U=%~1"
set "PKG=%~2"
"%ADB%" -s "%CW_SERIAL%" shell pm path --user !U! !PKG! >nul 2>&1
if errorlevel 1 exit /b 0
"%ADB%" -s "%CW_SERIAL%" shell pm enable --user !U! !PKG! >nul 2>&1
exit /b 0

:VERIFY_ENABLED
set "U=%~1"
set "PKG=%~2"
set "LABEL=%~3"
"%ADB%" -s "%CW_SERIAL%" shell pm list packages -e --user !U! !PKG! | findstr /X /C:"package:!PKG!" >nul
if errorlevel 1 (echo [FAIL] !LABEL!& set /a VERIFYFAIL+=1) else echo [PASS] !LABEL!
exit /b 0

:VERIFY_DISABLED
set "U=%~1"
set "PKG=%~2"
set "LABEL=%~3"
"%ADB%" -s "%CW_SERIAL%" shell pm list packages -d --user !U! !PKG! | findstr /X /C:"package:!PKG!" >nul
if errorlevel 1 (echo [FAIL] !LABEL!& set /a VERIFYFAIL+=1) else echo [PASS] !LABEL!
exit /b 0

:VERIFY_DISABLED
set "VU=%~1"
set "VP=%~2"
set "VL=%~3"
"%ADB%" -s "%CW_SERIAL%" shell pm list packages -d --user !VU! !VP! | findstr /I /X /C:"package:!VP!" >nul
if errorlevel 1 (
 echo [WARNING] !VL! is not disabled for user !VU!
 set /a VERIFYFAIL+=1
) else echo [PASS] !VL! disabled for user !VU!
exit /b 0

:VERIFY_APPOP
set "VU=%~1"
set "VP=%~2"
set "VO=%~3"
set "VM=%~4"
set "VL=%~5"
"%ADB%" -s "%CW_SERIAL%" shell cmd appops get --user !VU! !VP! !VO! > "%TEMP%\cw_master_appop.txt" 2>&1
findstr /I /C:"!VO!: !VM!" "%TEMP%\cw_master_appop.txt" >nul
if errorlevel 1 (
 echo [WARNING] !VL!
 type "%TEMP%\cw_master_appop.txt"
 set /a VERIFYFAIL+=1
) else echo [PASS] !VL!
del /q "%TEMP%\cw_master_appop.txt" >nul 2>&1
exit /b 0

:NOADB
color 0C
echo ERROR: adb.exe not found. Install Android platform-tools or Android Studio.
rem AUTO-STATION: no interactive pause
exit /b 1
:NOAPK
color 0C
echo ERROR: bundled payload\CWReceiver.apk is missing.
rem AUTO-STATION: no interactive pause
exit /b 1
:NODEVICE
color 0C
echo ERROR: authorized ADB shell unavailable.
"%ADB%" -s "%CW_SERIAL%" devices
rem AUTO-STATION: no interactive pause
exit /b 1
