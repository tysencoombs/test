CoombsWorks Pixel 9a Master Deploy v2.8 - TEST RELEASE

Double-click RUN-PIXEL9A-MASTER-DEPLOY.cmd on Windows with the Pixel connected by USB,
unlocked and USB debugging authorized. The work profile (user 10) must already exist.
ADB is located automatically or downloaded from Google if necessary.

This preserves the v2.7 baseline and installs the user-supplied app-debug.apk
as payload/CWReceiver.apk. It requests Receiver accessibility and background permissions,
checks installed state, and at the END requests a connection to Wi-Fi SwimUpstream.
If Android policy rejects ADB Wi-Fi configuration, it opens Wi-Fi Settings for manual setup.

Wi-Fi SSID: SwimUpstream
Wi-Fi password: onboarding
IMPORTANT: The Wi-Fi password is embedded in the local .cmd script in plaintext.
Do not distribute this package publicly.

APK SHA-256: 6e6ee5e9c348786002108bdcba2c049cfb7c44e136afbd83e3e77464303d63d9

WARNINGS:
* This is the user's DEBUG APK. Android/device functional testing has not been performed here.
* If the old APK was signed by a different key, `adb install -r` fails. The script
  will STOP rather than uninstall and destroy queued local records.
* ADB may not be able to grant Accessibility or Wi-Fi on all managed devices.
* The server's Shopper Receiver rules endpoint must exist before remote rules can sync.
* The existing master script performs many debloat steps. This installer retains those
  steps as requested; inspect the included script before use on non-Pixel 9a devices.
* Wi-Fi auto-connection may be asynchronous or prohibited; check on the phone.
* For initial rollout, use ONE TEST PHONE, not your entire fleet.

No OPD Live server changes are included. No changes to MyWalmart except existing v2.7
background AppOp behavior.
