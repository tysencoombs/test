This is the uploaded MasterDeploy v2.8 with an automatic Windows USB wrapper.
The original RUN-PIXEL9A-MASTER-DEPLOY.cmd is retained unchanged.
RUN-PIXEL9A-MASTER-DEPLOY-AUTO.cmd differs only in:
  (1) adb commands pinned with -s %CW_SERIAL% for multi-device safety
  (2) pause lines removed so the station can continue unattended.
Station auto-runs on newly attached authorized Pixel 9a devices.
Original master script changes user 0 and work profile user 10, installs bundled
CWReceiver debug APK, modifies accessibility/appops, and requests Wi-Fi
SwimUpstream with password onboarding. Managed work-profile changes may be
restricted by organizational policy; use only where authorized.
The original script requires user 10 to already exist. No automatic reboot.
Connect only one test phone first; this package has not been device-tested.
Python 3 and Android platform-tools (ADB) are required.
The original master script can download platform-tools if absent.
Logs are written to logs/ and restore files to the master folder.
